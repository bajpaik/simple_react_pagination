import React from 'react';
import FirstComponents from './FirstComponents'

import PaginationExample from './PaginationExample'
function App() {
  return (
    <div className="App">
        <FirstComponents/>
    </div>
  );
}

export default App;
